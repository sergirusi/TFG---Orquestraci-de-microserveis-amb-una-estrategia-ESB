package orquestrating_ms_v2;

import org.json.JSONObject;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;


public class transform extends AbstractTransformer{

	@Override
	protected Object doTransform(Object src, String enc) throws TransformerException {
		String input = (String) src;
		JSONObject json = new JSONObject(input);
		String name = (String) json.get("client_name");
		String age = (String) json.get("age");
		String phone = (String) json.get("phone_number");
		String email = (String) json.get("email");
		String res = "INSERT INTO users_data(client_name, age, phone_number, email) Values ('"+name+"', " + "'"+age+"', " + "'"+phone+"', " + "'"+email+"');"; 
		return res;
	}
}

