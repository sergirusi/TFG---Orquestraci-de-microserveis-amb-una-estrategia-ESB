package orquestrating_ms_v2;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;

public class DeleteClientTransform extends AbstractTransformer{

		@Override
		protected Object doTransform(Object src, String enc) throws TransformerException {
			String name = (String) src;
			String res = "DELETE FROM users_data WHERE client_name='" + name + "';";
			return res;
		}

}
