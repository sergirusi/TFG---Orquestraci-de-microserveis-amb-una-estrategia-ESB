package orquestrating_ms_v2;

import org.json.JSONObject;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;

public class UpdateClientTransform extends AbstractTransformer{

	@Override
	protected Object doTransform(Object src, String enc) throws TransformerException {
		String input = (String) src;
		JSONObject json = new JSONObject(input);
		String client_name = (String) json.get("client_name");
		String type = (String) json.get("type");
		String data = (String) json.get("data");
		String res = "UPDATE users_data SET " + type + " = '" + data + "' WHERE client_name = '" + client_name + "';"; 
		return res;
	}
}
