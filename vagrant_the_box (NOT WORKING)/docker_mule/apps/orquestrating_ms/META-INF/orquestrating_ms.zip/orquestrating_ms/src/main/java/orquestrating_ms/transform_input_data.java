package orquestrating_ms;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;
import org.json.simple.JSONObject;

public class transform_input_data extends AbstractTransformer{

	@Override
	protected Object doTransform(Object src, String enc) throws TransformerException {
		JSONObject json = (JSONObject) src;
		String name = (String) json.get("client_name");
		String age = (String) json.get("age");
		String phone = (String) json.get("phone_number");
		String email = (String) json.get("email");
		String res = "INSERT INTO clients(client_name, age, phone_number, email) Values ('"+name+"', " + "'"+age+"', " + "'"+phone+"', " + "'"+email+"');"; 
		return res;
	}
}
