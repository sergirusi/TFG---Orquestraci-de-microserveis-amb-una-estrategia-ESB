package orquestrating_ms_v2;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;

public class DBResponseTransform extends AbstractTransformer{

	@Override
	protected Object doTransform(Object src, String enc) throws TransformerException {
		String input = (String) src;
		String res = input.replace("\\", ""); //DELETE \ characters made by MySQL response
		res = res.replace("\"{", "{"); //DELETE " characters made by MySQL response
		res = res.replace("}\"", "}"); //DELETE " characters made by MySQL response
		res = res.replace(" ", "+");  //ADD + character in phone_number value
		return res;
	}

}
